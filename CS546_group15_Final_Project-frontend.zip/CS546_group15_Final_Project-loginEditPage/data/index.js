const shop = require('./shop');
const products = require('./products');
const user = require('./user');


module.exports = {
  shop: shop,
  products: products,
  user: user,

};